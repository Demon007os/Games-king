
import React from "react";
export default function App() {
  return (
    <main style={{ padding: '2rem', fontFamily: 'sans-serif', background: '#111', color: '#fff' }}>
      <header style={{ textAlign: 'center' }}>
        <h1 style={{ fontSize: '3rem' }}>GameVerse</h1>
        <p>Explore and Download Awesome Games</p>
      </header>
      <section style={{ display: 'grid', gap: '1.5rem', marginTop: '2rem' }}>
        <div style={{ background: '#222', padding: '1rem', borderRadius: '0.5rem' }}>
          <h2>Space Blaster</h2>
          <p>Arcade shooter. Defend Earth!</p>
          <a href='/downloads/space-blaster.zip' download style={{ color: '#0af' }}>Download</a>
        </div>
        <div style={{ background: '#222', padding: '1rem', borderRadius: '0.5rem' }}>
          <h2>Zombie Escape</h2>
          <p>Survive the zombie outbreak!</p>
          <a href='/downloads/zombie-escape.zip' download style={{ color: '#0af' }}>Download</a>
        </div>
        <div style={{ background: '#222', padding: '1rem', borderRadius: '0.5rem' }}>
          <h2>Watch Trailers</h2>
          <p>Catch the latest game videos</p>
          <a href='/videos' style={{ color: '#0af' }}>Watch Now</a>
        </div>
      </section>
      <footer style={{ textAlign: 'center', marginTop: '3rem', color: '#777' }}>
        &copy; 2025 GameVerse. All rights reserved.
      </footer>
    </main>
  );
}
